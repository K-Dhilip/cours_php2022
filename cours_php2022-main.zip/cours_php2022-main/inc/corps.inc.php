<?php

    echo "<h2>Ceci est le corps du document</h2>
    <hr>
    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Hic similique sint culpa quo natus aliquid voluptatum a et corrupti mollitia placeat doloremque excepturi iure aliquam voluptatem, nesciunt laboriosam sapiente cum! Lorem ipsum dolor sit amet consectetur adipisicing elit. Corrupti perspiciatis, sed dolorum quia dicta quas dolore modi accusamus nemo ea quisquam, numquam, illo optio cum? Dolores, blanditiis? Sint, impedit id!</p>";

    echo "<p>Nom du fichier inclus : ". __FILE__ ."</p>";
// ici la balise php n'est pas fermée
// Fermer cette balise n'est pas obligatoire, mais il faut toujours l'ouvrir. 