<footer class="footer mt-auto py-3 bg-secondary">
  <div class="container">
    <p class="text-dark">Cours PHP_7 - &copy <?php echo date('Y') ?></p>
  </div>
</footer>