// $(document).ready(function(){
//     $('#sidebarCollapse').on('click', function () {
//     $('#sidebar').toggleClass('active');
//     $(this).toggleClass('active');
//     $(".col-sm-8").toggleClass('col-sm-10');
// });
// });