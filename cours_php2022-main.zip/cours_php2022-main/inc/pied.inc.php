<hr>

    <?php
        echo "<div>
        <p>Fin de la page PHP : un lien utile : <a href=\"https://www.php.net/\">Le site de PHP</a></p>
    </div>";



    ?>

</body>
</html>