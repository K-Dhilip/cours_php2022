<?php
    include_once("../inc/tete.inc.php"); // include_once (ou require_once) sera exécuté une seule fois
    include_once("../inc/corps.inc.php"); // require peut générer une erreur fatale
    require_once("../inc/pied.inc.php");
?>